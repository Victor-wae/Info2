public class FListMerge {

    /*
     * This method receives an FList and returns a new FList containing the same values but sorted in ascending order.
     *
     */
    public static FList<Integer> mergeSort(FList<Integer> fList){
        // TODO By Student
    }

    // TO Complete if necessary
}