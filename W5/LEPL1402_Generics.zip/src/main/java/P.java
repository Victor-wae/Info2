interface P {
    boolean filter(int v);
}