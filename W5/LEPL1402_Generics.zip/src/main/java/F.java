interface F {
    int apply(int v);
}