public class MagicSquare {


    /**
     * A magic square is an (n x n) matrix such that:
     *
     * - all the positive numbers 1,2, ..., n*n are present (thus each number appears exactly once)
     * - the sums of the numbers in each row, each column and both main diagonals are the same
     *
     *   For instance a 3 x 3 magic square is the following
     *
     *   2 7 6
     *   9 5 1
     *   4 3 8
     *
     *   You have to implement the method that verifies if a matrix is a valid magic square
     */

    /**
     *
     * @param matrix a square matrix of size n x n
     * @return true if matrix is a n x n magic square, false otherwise
     */
    public static boolean isMagicSquare(int [][] matrix) {
        // TODO Implement the body of this method, feel free to add other methods but do not change the signature of isMagiSquare

        boolean[][] x = new boolean[matrix.length][matrix[0].length];
        for (int i = 0; i < matrix.length; i++){
            for(int j = 0; j < matrix.length;j++){
                int k = 0;
                int val = matrix[i][j];
                while (val > matrix.length){
                    k++;
                    val = val - matrix.length;
                }
                if (val <= 0)return false;
                if (x[k][val-1] == true)return false;
                x[k][val-1] = true;
            }
        }
        for (int i = 0; i < matrix.length; i++){
            for(int j = 0; j < matrix.length;j++){
                if (x[i][j] == false)return false;
            }
        }
        if (somme(matrix)) return true;
        return false;
    }
    public static boolean somme(int[][] m){
        int[]x = new int[m.length*2+1];
        for (int i = 0; i < m.length; i++){
            int s = 0;
            for (int j = 0; j < m[0].length ; j++){
                s = s + m[i][j];
            }
            x[i] = s;
        }
        for (int j = 0; j < m[0].length; j++){
            int s = 0;
            for (int i = 0; i < m.length; i++){
                s = s + m[i][j];
            }
            x[m.length-1 + j] = s;
        }
        int s = 0;
        for (int i = 0; i < m.length; i++){
            s += m[i][i];
        }
        x[m.length*2-1] = s;
        s = 0;
        for (int i = m.length-1; i >= 0;i--){
            s += m[i][i];
        }
        x[m.length*2] = s;
        int comp = x[0];
        for (int i = 1; i < x.length; i++){
            if (x[i] != comp)return false;
        }
        return true;
    }
}
